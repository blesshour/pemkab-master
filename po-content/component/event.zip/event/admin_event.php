<?php
/*
 *
 * - PopojiCMS Admin File
 *
 * - File : admin_video.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - License : MIT License
 *
 *
 * Ini adalah file php yang di gunakan untuk menangani proses admin pada halaman video.
 * This is a php file for handling admin process for video page.
 *
*/

/**
 * Fungsi ini digunakan untuk mencegah file ini diakses langsung tanpa melalui router.
 *
 * This function use for prevent this file accessed directly without going through a router.
 *
*/
if (!defined('CONF_STRUCTURE')) {
	header('location:index.html');
	exit;
}

/**
 * Fungsi ini digunakan untuk mencegah file ini diakses langsung tanpa login akses terlebih dahulu.
 *
 * This function use for prevent this file accessed directly without access login first.
 *
*/
if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser']) AND $_SESSION['login'] == 0) {
	header('location:index.php');
	exit;
}

class Event extends PoCore
{

	/**
	 * Fungsi ini digunakan untuk menginisialisasi class utama.
	 *
	 * This function use to initialize the main class.
	 *
	*/
	function __construct()
	{
		parent::__construct();
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan halaman index video.
	 *
	 * This function use for index video page.
	 *
	*/
	public function index()
	{
		if (!$this->auth($_SESSION['leveluser'], 'event', 'read')) {
			echo $this->pohtml->error();
			exit;
		}

		?>
			<div class="block-content">
				<div class="row">
					<div class="col-md-12">
						<?=$this->pohtml->headTitle('Event', '
							<div class="btn-title pull-right">
								<a href="admin.php?mod=event&act=addnew" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> '.$GLOBALS['_']['addnew'].'</a>
							</div>
						');?>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=event&act=multidelete', 'autocomplete' => 'off'));?>
							<?=$this->pohtml->inputHidden(array('name' => 'totaldata', 'value' => '0', 'options' => 'id="totaldata"'));?>
							<?php
								$columns = array(
									array('title' => 'Id', 'options' => 'style="width:30px;"'),
									array('title' => 'Date Mulai', 'options' => ''),
									array('title' => 'Date Akhir', 'options' => ''),
									array('title' => 'Nama Event', 'options' => ''),
									array('title' => 'Deskripsi Event', 'options' => ''),
									array('title' => 'Tampilkan', 'options' => 'style="width:50px;"'),
									array('title' => 'Action', 'options' => 'class="no-sort" style="width:50px;"')
								);
							?>
							<?=$this->pohtml->createTable(array('id' => 'table-event', 'class' => 'table table-striped table-bordered'), $columns, $tfoot = true);?>
						<?=$this->pohtml->formEnd();?>
					</div>
				</div>
			</div>
			<?=$this->pohtml->dialogDelete('event');?>
			<?php
					
				}

	/**
	 * Fungsi ini digunakan untuk menampilkan data json pada tabel.
	 *
	 * This function use for display json data in table.
	 *
	*/
	public function datatable()
	{
		if (!$this->auth($_SESSION['leveluser'], 'event', 'read')) {
			echo $this->pohtml->error();
			exit;
		}

		$table = 'event';
		$primarykey = 'id_event';
		$columns = array(
			array('db' => $primarykey, 'dt' => '0', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>
						<input type='checkbox' id='titleCheckdel' />
						<input type='hidden' class='deldata' name='item[".$i."][deldata]' value='".$d."' disabled />
					</div>";
				}
			),
			array('db' => $primarykey, 'dt' => '1', 'field' => $primarykey),
			array('db' => 'date_mulai', 'dt' => '2', 'field' => 'date_mulai'),
			array('db' => 'date_akhir', 'dt' => '3', 'field' => 'date_akhir'),
			array('db' => 'nama_event', 'dt' => '4', 'field' => 'nama_event'),
			array('db' => 'desc_event', 'dt' => '5', 'field' => 'desc_event'),
			array('db' => 'tampilkan', 'dt' => '6', 'field' => 'headline',
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>".$d."</div>";
				}
			),
			array('db' => $primarykey, 'dt' => '7', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>
						<div class='btn-group btn-group-xs'>
							<a href='admin.php?mod=event&act=edit&id=".$row['id_event']."' class='btn btn-xs btn-default' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_1']}'><i class='fa fa-pencil'></i></a>
							<a class='btn btn-xs btn-danger alertdel' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_2']}'><i class='fa fa-times'></i></a>
						</div>
					</div>";
				}
			)
		);
		echo json_encode(SSP::simple($_POST, $this->poconnect, $table, $primarykey, $columns));
		
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman tambah video.
	 *
	 * This function is used to display and process add video page.
	 *
	*/
	public function addnew()
	{
		if (!$this->auth($_SESSION['leveluser'], 'event', 'create')) {
			echo $this->pohtml->error();
			exit;
		}

		if (!empty($_POST)) {
		$event = array(
			'date_mulai' => date('Y-m-d'),
			'date_akhir' => date('Y-m-d'),
			'nama_event' => $this->postring->valid($_POST['nama_event'], 'xss'),
			'desc_event' => $this->postring->valid($_POST['desc_event'], 'xss')
			
		);
		$query_event = $this->podb->insertInto('event')->values($event);
		$query_event->execute();
		$this->poflash->success('Event has been successfully added', 'admin.php?mod=event');
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Add Event');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=event&act=addnew', 'autocomplete' => 'off'));?>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'date', 'label' => 'Date Mulai', 'name' => 'date_mulai', 'id' => 'date_mulai', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'date', 'label' => 'Date Akhir ', 'name' => 'date_akhir', 'id' => 'date_akhir', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Nama Event', 'name' => 'nama_event', 'id' => 'nama_event', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Nama Deskripsi', 'name' => 'desc_event', 'id' => 'desc_event', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
		
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman edit video.
	 *
	 * This function is used to display and process edit video.
	 *
	*/
	public function edit()
	{
		if (!$this->auth($_SESSION['leveluser'], 'event', 'update')) {
			echo $this->pohtml->error();
			exit;
		}

		if (!empty($_POST)) {
		$event = array(
			'date_mulai' => date('Y-m-d'),
			'date_akhir' => date('Y-m-d'),
			'nama_event' => $this->postring->valid($_POST['nama_event'], 'xss'),
			'desc_event' => $this->postring->valid($_POST['desc_event'], 'xss'),
			'tampilkan' => $this->postring->valid($_POST['tampilkan'], 'xss')
		);
		$query_event = $this->podb->update('event')
			->set($event)
			->where('id_event', $this->postring->valid($_POST['id'], 'sql'));
		$query_event->execute();
		$this->poflash->success('Event has been successfully updated', 'admin.php?mod=event');
		}
		$id = $this->postring->valid($_GET['id'], 'sql');
		$current_event = $this->podb->from('event')
			->where('id_event', $id)
			->limit(1)
			->fetch();
		if (empty($current_event)) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Update Event');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=event&act=edit', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'id', 'value' => $current_event['id_event']));?>
						<div class="row">
							<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'date', 'label' => 'Date Mulai', 'name' => 'date_mulai', 'id' => 'date_mulai', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'date', 'label' => 'Date Akhir ', 'name' => 'date_akhir', 'id' => 'date_akhir', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Nama Event', 'name' => 'nama_event', 'id' => 'nama_event', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Nama Deskripsi', 'name' => 'desc_event', 'id' => 'desc_event', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?php
									if ($current_event['tampilkan'] == 'N') {
										$radioitem = array(
											array('name' => 'tampilkan', 'id' => 'tampilkan1', 'value' => 'Y', 'options' => '', 'title' => 'Y'),
											array('name' => 'tampilkan', 'id' => 'tampilkan2', 'value' => 'N', 'options' => 'checked', 'title' => 'N')
										);
										echo $this->pohtml->inputRadio(array('label' => 'Tampilkan', 'mandatory' => true), $radioitem, $inline = true);
									} else {
										$radioitem = array(
											array('name' => 'tampilkan', 'id' => 'tampilkan1', 'value' => 'Y', 'options' => 'checked', 'title' => 'Y'),
											array('name' => 'tampilkan', 'id' => 'tampilkan2', 'value' => 'N', 'options' => '', 'title' => 'N')
										);
										echo $this->pohtml->inputRadio(array('label' => 'Tampilkan', 'mandatory' => true), $radioitem, $inline = true);
									}
								?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
		
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus video.
	 *
	 * This function is used to display and process delete video page.
	 *
	*/
	public function delete()
	{
		if (!$this->auth($_SESSION['leveluser'], 'event', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}

		if (!empty($_POST)) {
			$query = $this->podb->deleteFrom('event')->where('id_event', $this->postring->valid($_POST['id'], 'sql'));
			$query->execute();
			$this->poflash->success('Event has been successfully deleted', 'admin.php?mod=event');
		}
		
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus multi video.
	 *
	 * This function is used to display and process multi delete video page.
	 *
	*/
	public function multidelete()
	{
		if (!$this->auth($_SESSION['leveluser'], 'event', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}

		if (!empty($_POST)) {
			$totaldata = $this->postring->valid($_POST['totaldata'], 'xss');
			if ($totaldata != "0") {
				$items = $_POST['item'];
				foreach($items as $item){
					$query = $this->podb->deleteFrom('event')->where('id_event', $this->postring->valid($item['deldata'], 'sql'));
					$query->execute();
				}
				$this->poflash->success('Event has been successfully deleted', 'admin.php?mod=event');
			} else {
				$this->poflash->error('Error deleted event data', 'admin.php?mod=event');
			}
		}
		
	}


}

?>