<?php
/*
 *
 * - PopojiCMS Admin File
 *
 * - File : admin_banner.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - License : MIT License
 *
 *
 * Ini adalah file php yang di gunakan untuk menangani proses admin pada halaman banner.
 * This is a php file for handling admin process for banner page.
 *
*/

/**
 * Fungsi ini digunakan untuk mencegah file ini diakses langsung tanpa melalui router.
 *
 * This function use for prevent this file accessed directly without going through a router.
 *
*/
if (!defined('CONF_STRUCTURE')) {
	header('location:index.html');
	exit;
}

/**
 * Fungsi ini digunakan untuk mencegah file ini diakses langsung tanpa login akses terlebih dahulu.
 *
 * This function use for prevent this file accessed directly without access login first.
 *
*/
if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser']) AND $_SESSION['login'] == 0) {
	header('location:index.php');
	exit;
}

class Banner extends PoCore
{

	/**
	 * Fungsi ini digunakan untuk menginisialisasi class utama.
	 *
	 * This function use to initialize the main class.
	 *
	*/
	function __construct()
	{
		parent::__construct();
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan halaman index banner.
	 *
	 * This function use for index banner page.
	 *
	*/
	public function index()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'read')) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Banner', '
						<div class="btn-title pull-right">
							<a href="admin.php?mod=banner&act=addnew" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> '.$GLOBALS['_']['addnew'].'</a>
						</div>
					');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=multidelete', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'totaldata', 'value' => '0', 'options' => 'id="totaldata"'));?>
						<?php
							$columns = array(
								array('title' => 'ID', 'options' => 'style="width:30px;"'),
								array('title' => 'Caption Banner', 'options' => ''),
								array('title' => 'Picture', 'options' => ''),
								array('title' => 'Tampilkan', 'options' => 'style="width:50px;"'),
								array('title' => 'Action', 'options' => 'class="no-sort" style="width:50px;"')
							);
						?>
						<?=$this->pohtml->createTable(array('id' => 'table-banner', 'class' => 'table table-striped table-bordered'), $columns, $tfoot = true);?>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?=$this->pohtml->dialogDelete('banner');?>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan data json pada tabel.
	 *
	 * This function use for display json data in table.
	 *
	*/
	public function datatable()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'read')) {
			echo $this->pohtml->error();
			exit;
		}
		$table = 'banner';
		$primarykey = 'id_banner';
		$columns = array(
			array('db' => $primarykey, 'dt' => '0', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>
						<input type='checkbox' id='titleCheckdel' />
						<input type='hidden' class='deldata' name='item[".$i."][deldata]' value='".$d."' disabled />
					</div>";
				}
			),
			array('db' => $primarykey, 'dt' => '1', 'field' => $primarykey),
			array('db' => 'capt_banner', 'dt' => '2', 'field' => 'capt_banner'),
			array('db' => 'picture', 'dt' => '3', 'field' => 'picture',
				'formatter' => function($d, $row, $i){
					return "<a href='../".DIR_CON."/uploads/".$row['picture']."' target='_blank'>".$d."</a>";
				}
			),
			array('db' => 'tampilkan', 'dt' => '4', 'field' => 'tampilkan',
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>".$d."</div>";
				}
			),
			array('db' => $primarykey, 'dt' => '5', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>
						<div class='btn-group btn-group-xs'>
							<a href='admin.php?mod=banner&act=edit&id=".$row['id_banner']."' class='btn btn-xs btn-default' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_1']}'><i class='fa fa-pencil'></i></a>
							<a class='btn btn-xs btn-danger alertdel' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_2']}'><i class='fa fa-times'></i></a>
						</div>
					</div>";
				}
			),
			array('db' => 'picture', 'dt' => '', 'field' => 'picture'),
		);
		$joinquery = "FROM banner JOIN picture AS a ON id_banner";
		echo json_encode(SSP::simple($_POST, $this->poconnect, $table, $primarykey, $columns));
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman tambah banner.
	 *
	 * This function is used to display and process add banner page.
	 *
	*/
	public function addnew()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'create')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$banner = array(
				'capt_banner' => stripslashes(htmlspecialchars($_POST['capt_banner'],ENT_QUOTES)),
				'picture' => $_POST['picture']
			);
			$query_banner = $this->podb->insertInto('banner')->values($banner);
			$query_banner->execute();
			$this->poflash->success('Banner has been successfully added', 'admin.php?mod=banner');
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Add Banner');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=addnew', 'autocomplete' => 'off'));?>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Caption Banner', 'name' => 'capt_banner', 'id' => 'banner', 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="input-group">
									<?php
										$pictures = $this->podb->from('picture')
											->where('active', 'Y')
											->orderBy('id_banner DESC')
											->fetchAll();
										echo $this->pohtml->inputSelectNoOpt(array('id' => 'id_banner', 'label' => 'Banner', 'name' => 'banner', 'mandatory' => true));
										foreach($pictures as $picture){
											echo '<option value="'.$picture['id_banner'].'">'.$picture['capt_banner'].'</option>';
										}
										echo $this->pohtml->inputSelectNoOptEnd();
									?>
									<span class="input-group-btn" style="padding-top:25px !important;">
										<a href="admin.php?mod=banner&act=addnewbanner" class="btn btn-success"><?=$GLOBALS['_']['addnew'];?></a>
									</span>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman edit banner.
	 *
	 * This function is used to display and process edit banner.
	 *
	*/
	public function edit()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'update')) {
			echo $this->pohtml->error();
			exit;
		}
				if (!empty($_POST)) {
			$banner = array(
				'capt_banner' => $this->postring->valid($_POST['capt_banner'], 'xss'),
				'tampilkan' => $this->postring->valid($_POST['tampilkan'], 'xss')
			);
			$query_banner = $this->podb->update('banner')
				->set($banner)
				->where('id_banner', $this->postring->valid($_POST['id'], 'sql'));
			$query_banner->execute();
			$this->poflash->success('Banner has been successfully updated', 'admin.php?mod=banner');
		}
		$id = $this->postring->valid($_GET['id'], 'sql');
		$current_banner = $this->podb->from('banner')
			->where('id_banner', $id)
			->limit(1)
			->fetch();
		if (empty($current_banner)) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Update Banner');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=edit', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'id', 'value' => $current_banner['id_banner']));?>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Caption Banner', 'name' => 'capt_banner', 'id' => 'id_banner', 'value' => $current_banner['banner'], 'mandatory' => true, 'options' => 'required', 'help' => '<small>&nbsp;</small>'));?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?php
									if ($current_banner['tampilkan'] == 'N') {
										$radioitem = array(
											array('name' => 'tampilkan', 'id' => 'tampilkan1', 'value' => 'Y', 'options' => '', 'title' => 'Y'),
											array('name' => 'tampilkan', 'id' => 'tampilkan2', 'value' => 'N', 'options' => 'checked', 'title' => 'N')
										);
										echo $this->pohtml->inputRadio(array('label' => 'Tampilkan', 'mandatory' => true), $radioitem, $inline = true);
									} else {
										$radioitem = array(
											array('name' => 'tampilkan', 'id' => 'tampilkan1', 'value' => 'Y', 'options' => 'checked', 'title' => 'Y'),
											array('name' => 'tampilkan', 'id' => 'tampilkan2', 'value' => 'N', 'options' => '', 'title' => 'N')
										);
										echo $this->pohtml->inputRadio(array('label' => 'Tampilkan', 'mandatory' => true), $radioitem, $inline = true);
									}
								?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus banner.
	 *
	 * This function is used to display and process delete banner page.
	 *
	*/
	public function delete()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
		$query = $this->podb->deleteFrom('banner')->where('id_banner', $this->postring->valid($_POST['id'], 'sql'));
		$query->execute();
		$this->poflash->success('Banner has been successfully deleted', 'admin.php?mod=banner');
	}
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus multi banner.
	 *
	 * This function is used to display and process multi delete banner page.
	 *
	*/
	public function multidelete()
	{
		if (!$this->auth($_SESSION['leveluser'], 'pengbannerumuman', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
		$totaldata = $this->postring->valid($_POST['totaldata'], 'xss');
		if ($totaldata != "0") {
			$items = $_POST['item'];
			foreach($items as $item){
				$query = $this->podb->deleteFrom('banner')->where('id_banner', $this->postring->valid($item['deldata'], 'sql'));
				$query->execute();
			}
			$this->poflash->success('Banner has been successfully deleted', 'admin.php?mod=banner');
		} else {
			$this->poflash->error('Error deleted banner data', 'admin.php?mod=banner');
		}
	}
	}

}
?>

