/*
 *
 * - PopojiCMS Javascript
 *
 * - File : admin_javascript.js
 * - Version : 1.0
 * - Author : Author Name
 * - License : MIT License
 *
 *
 * Ini adalah file utama javascript PopojiCMS yang memuat semua javascript di halaman banner.
 * This is a main javascript file from PopojiCMS which contains all javascript in banner page.
 *
*/

$(document).ready(function() {
	$('#table-banner').buildtable('route.php?mod=banner&act=datatable');
});