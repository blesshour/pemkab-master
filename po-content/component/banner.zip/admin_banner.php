<?php
/*
 *
 * - PopojiCMS Admin File
 *
 * - File : admin_banner.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - License : MIT License
 *
 *
 * Ini adalah file php yang di gunakan untuk menangani proses admin pada halaman banner.
 * This is a php file for handling admin process for banner page.
 *
*/

/**
 * Fungsi ini digunakan untuk mencegah file ini diakses langsung tanpa melalui router.
 *
 * This function use for prevent this file accessed directly without going through a router.
 *
*/
if (!defined('CONF_STRUCTURE')) {
	header('location:index.html');
	exit;
}

/**
 * Fungsi ini digunakan untuk mencegah file ini diakses langsung tanpa login akses terlebih dahulu.
 *
 * This function use for prevent this file accessed directly without access login first.
 *
*/
if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser']) AND $_SESSION['login'] == 0) {
	header('location:index.php');
	exit;
}

class Banner extends PoCore
{

	/**
	 * Fungsi ini digunakan untuk menginisialisasi class utama.
	 *
	 * This function use to initialize the main class.
	 *
	*/
	function __construct()
	{
		parent::__construct();
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan halaman index banner.
	 *
	 * This function use for index banner page.
	 *
	*/
	public function index()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'read')) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Banner', '
						<div class="btn-title pull-right">
							<a href="admin.php?mod=banner&act=addnew" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> '.$GLOBALS['_']['addnew'].'</a>
							<a href="admin.php?mod=banner&act=judul" class="btn btn-success btn-sm"><i class="fa fa-book"></i> Judul</a>
						</div>
					');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=multidelete', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'totaldata', 'value' => '0', 'options' => 'id="totaldata"'));?>
						<?php
							$columns = array(
								array('title' => 'Id', 'options' => 'style="width:30px;"'),
								array('title' => 'Judul', 'options' => ''),
								array('title' => 'Title', 'options' => ''),
								array('title' => 'Action', 'options' => 'class="no-sort" style="width:50px;"')
							);
						?>
						<?=$this->pohtml->createTable(array('id' => 'banner', 'class' => 'table table-striped table-bordered'), $columns, $tfoot = true);?>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?=$this->pohtml->dialogDelete('banner');?>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan data json pada tabel.
	 *
	 * This function use for display json data in table.
	 *
	*/
	public function datatable()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'read')) {
			echo $this->pohtml->error();
			exit;
		}
		$table = 'banner';
		$primarykey = 'id_banner';
		$columns = array(
			array('db' => 'b.'.$primarykey, 'dt' => '0', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>\n
						<input type='checkbox' id='titleCheckdel' />\n
						<input type='hidden' class='deldata' name='item[".$i."][deldata]' value='".$d."' disabled />\n
					</div>\n";
				}
			),
			array('db' => 'b.'.$primarykey, 'dt' => '1', 'field' => $primarykey),
			array('db' => 'j.title as jdl_title', 'dt' => '2', 'field' => 'jdl_title'),
			array('db' => 'b.title as ban_title', 'dt' => '3', 'field' => 'ban_title',
				'formatter' => function($d, $row, $i){
					return "<a href='../".DIR_CON."/uploads/".$row['picture']."' target='_blank'>".$d."</a>";
				}
			),
			array('db' => 'b.'.$primarykey, 'dt' => '4', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>\n
						<div class='btn-group btn-group-xs'>\n
							<a href='admin.php?mod=banner&act=edit&id=".$d."' class='btn btn-xs btn-default' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_1']}'><i class='fa fa-pencil'></i></a>
							<a class='btn btn-xs btn-danger alertdel' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_2']}'><i class='fa fa-times'></i></a>
						</div>\n
					</div>\n";
				}
			),
			array('db' => 'b.picture', 'dt' => '', 'field' => 'picture'),
		);
		$joinquery = "FROM banner AS b JOIN judul AS j ON (j.id_judul = b.id_judul)";
		echo json_encode(SSP::simple($_POST, $this->poconnect, $table, $primarykey, $columns, $joinquery));
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman tambah banner.
	 *
	 * This function is used to display and process add banner page.
	 *
	*/
	public function addnew()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'create')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$banner = array(
				'id_banner' => $this->postring->valid($_POST['id_banner'], 'sql'),
				'title' => $this->postring->valid($_POST['title'], 'xss'),				
				'picture' => $_POST['picture']
			);
			$query_banner = $this->podb->insertInto('banner')->values($banner);
			$query_banner->execute();
			$this->poflash->success('Banner has successfully added', 'admin.php?mod=banner');
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Add Banner');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=addnew', 'autocomplete' => 'off'));?>
						<div class="row">
							<div class="col-md-5">
								<div class="input-group">
									<?php
										$jdls = $this->podb->from('judul')
											->where('active', 'Y')
											->orderBy('id_judul DESC')
											->fetchAll();
										echo $this->pohtml->inputSelectNoOpt(array('id' => 'id_judul', 'label' => 'Judul Banner', 'name' => 'id_judul', 'mandatory' => true));
										foreach($jdls as $jdl){
											echo '<option value="'.$jdl['id_judul'].'">'.$jdl['title'].'</option>';
										}
										echo $this->pohtml->inputSelectNoOptEnd();
									?>
									<span class="input-group-btn" style="padding-top:25px !important;">
										<a href="admin.php?mod=banner&act=addnewbanner" class="btn btn-success">Tambah</a>
									</span>
								</div>
							</div>
							<div class="col-md-7">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Title Banner', 'name' => 'title', 'id' => 'title', 'mandatory' => true, 'options' => 'required'));?>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-6">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Picture', 'name' => 'picture', 'id' => 'picture', 'mandatory' => true, 'options' => 'required',), $inputgroup = true, $inputgroupopt = array('href' => '../'.DIR_INC.'/js/filemanager/dialog.php?type=1&field_id=picture', 'id' => 'browse-file', 'class' => 'btn-success', 'options' => '', 'title' => 'Pilih Picture'));?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman edit banner.
	 *
	 * This function is used to display and process edit banner.
	 *
	*/
	public function edit()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'update')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$banner = array(
				'id_judul' => $this->postring->valid($_POST['id_judul'], 'sql'),
				'title' => $this->postring->valid($_POST['title'], 'xss'),
				'picture' => $_POST['picture']
			);
			$query_banner = $this->podb->update('banner')
				->set($banner)
				->where('id_banner', $this->postring->valid($_POST['id'], 'sql'));
			$query_banner->execute();
			$this->poflash->success($GLOBALS['_']['banner_message_2'], 'admin.php?mod=banner');
		}
		$id = $this->postring->valid($_GET['id'], 'sql');
		$current_banner = $this->podb->from('banner')
			->select('judul.title AS judul_title')
			->leftJoin('judul ON judul.id_judul = banner.id_judul')
			->where('banner.id_banner', $id)
			->limit(1)
			->fetch();
		if (empty($current_banner)) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle($GLOBALS['_']['banner_edit']);?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=edit', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'id', 'value' => $current_banner['id_banner']));?>
						<div class="row">
							<div class="col-md-5">
								<div class="input-group">
									<?php
										$jdls = $this->podb->from('judul')
											->where('active', 'Y')
											->orderBy('id_judul DESC')
											->fetchAll();
										echo $this->pohtml->inputSelectNoOpt(array('id' => 'id_judul', 'label' => $GLOBALS['_']['banner_judul'], 'name' => 'id_judul', 'mandatory' => true));
										echo '<option value="'.$current_banner['id_judul'].'">'.$GLOBALS['_']['banner_select'].' - '.$current_banner['judul_title'].'</option>';
										foreach($jdls as $jdl){
											echo '<option value="'.$jdl['id_judul'].'">'.$jdl['title'].'</option>';
										}
										echo $this->pohtml->inputSelectNoOptEnd();
									?>
									<span class="input-group-btn" style="padding-top:25px !important;">
										<a href="admin.php?mod=banner&act=addnewjudul" class="btn btn-success"><?=$GLOBALS['_']['addnew'];?></a>
									</span>
								</div>
							</div>
							<div class="col-md-7">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => $GLOBALS['_']['banner_title'], 'name' => 'title', 'id' => 'title', 'value' => $current_banner['title'], 'mandatory' => true, 'options' => 'required'));?>
							</div>
						</div>

						<div class="row">
							<div class="col-md-6">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => $GLOBALS['_']['bannerbanner_picture'], 'name' => 'picture', 'id' => 'picture', 'value' => $current_banner['picture'], 'mandatory' => true, 'options' => 'required',), $inputgroup = true, $inputgroupopt = array('href' => '../'.DIR_INC.'/js/filemanager/dialog.php?type=1&field_id=picture', 'id' => 'browse-file', 'class' => 'btn-success', 'options' => '', 'title' => $GLOBALS['_']['action_7'].' '.$GLOBALS['_']['banner_picture']));?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus banner.
	 *
	 * This function is used to display and process delete banner page.
	 *
	*/
	public function delete()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$query = $this->podb->deleteFrom('banner')->where('id_banner', $this->postring->valid($_POST['id'], 'sql'));
			$query->execute();
			$this->poflash->success('Banner has been successfully deleted', 'admin.php?mod=banner');
		}
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus multi banner.
	 *
	 * This function is used to display and process multi delete banner page.
	 *
	*/
	public function multidelete()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$totaldata = $this->postring->valid($_POST['totaldata'], 'xss');
			if ($totaldata != "0") {
				$items = $_POST['item'];
				foreach($items as $item){
					$query = $this->podb->deleteFrom('banner')->where('id_banner', $this->postring->valid($item['deldata'], 'sql'));
					$query->execute();
				}
				$this->poflash->success('Banner has been successfully deleted', 'admin.php?mod=banner');
			} else {
				$this->poflash->error('Error deleted banner data', 'admin.php?mod=banner');
			}
		}
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan halaman index judul.
	 *
	 * This function use for index judul page.
	 *
	*/
	public function judul()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'read')) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle ('Judul', '
						<div class="btn-title pull-right">
							<a href="admin.php?mod=banner&act=addnewjudul" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Tambah Judul</a>
							<a href="admin.php?mod=banner" class="btn btn-success btn-sm"><i class="fa fa-picture-o"></i> Kembali ke Banner</a>
						</div>
					');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=multideletejudul', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'totaldata', 'value' => '0', 'options' => 'id="totaldata"'));?>
						<?php
							$columns = array(
								array('title' => 'Id', 'options' => 'style="width:30px;"'),
								array('title' => 'Title Banner', 'options' => ''),
								array('title' => 'Aktif', 'options' => 'class="no-sort" style="width:50px;"'),
								array('title' => 'Action', 'options' => 'class="no-sort" style="width:50px;"')
							);
						?>
						<?=$this->pohtml->createTable(array('id' => 'table-judul', 'class' => 'table table-striped table-bordered'), $columns, $tfoot = true);?>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?=$this->pohtml->dialogDelete('banner', 'deletejudul');?>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan data json pada tabel.
	 *
	 * This function use for display json data in table.
	 *
	*/
	public function datatable2()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'read')) {
			echo $this->pohtml->error();
			exit;
		}
		$table = 'judul';
		$primarykey = 'id_judul';
		$columns = array(
			array('db' => $primarykey, 'dt' => '0', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>\n
						<input type='checkbox' id='titleCheckdel' />\n
						<input type='hidden' class='deldata' name='item[".$i."][deldata]' value='".$d."' disabled />\n
					</div>\n";
				}
			),
			array('db' => $primarykey, 'dt' => '1', 'field' => $primarykey),
			array('db' => 'title', 'dt' => '2', 'field' => 'title'),
			array('db' => 'active', 'dt' => '3', 'field' => 'active',
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>".$d."</div>\n";
				}
			),
			array('db' => $primarykey, 'dt' => '4', 'field' => $primarykey,
				'formatter' => function($d, $row, $i){
					return "<div class='text-center'>\n
						<div class='btn-group btn-group-xs'>\n
							<a href='admin.php?mod=banner&act=editjudul&id=".$d."' class='btn btn-xs btn-default' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_1']}'><i class='fa fa-pencil'></i></a>
							<a class='btn btn-xs btn-danger alertdel' id='".$d."' data-toggle='tooltip' title='{$GLOBALS['_']['action_2']}'><i class='fa fa-times'></i></a>
						</div>\n
					</div>\n";
				}
			)
		);
		echo json_encode(SSP::simple($_POST, $this->poconnect, $table, $primarykey, $columns));
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman tambah judul.
	 *
	 * This function is used to display and process add judul page.
	 *
	*/
	public function addnewjudul()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'create')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$judul = array(
				'title' => $this->postring->valid($_POST['title'], 'xss'),
				'seotitle' => $this->postring->seo_title($this->postring->valid($_POST['title'], 'xss'))
			);
			$query_judul = $this->podb->insertInto('judul')->values($judul);
			$query_judul->execute();
			$this->poflash->success('Judul has been successfully added', 'admin.php?mod=banner&act=judul');
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle('Tambah Judul');?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=addnewjudul', 'autocomplete' => 'off'));?>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => 'Title Banner', 'name' => 'title', 'id' => 'title', 'mandatory' => true, 'options' => 'required'));?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman edit judul.
	 *
	 * This function is used to display and process edit judul.
	 *
	*/
	public function editjudul()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'update')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$judul = array(
				'title' => $this->postring->valid($_POST['title'], 'xss'),
				'seotitle' => $this->postring->seo_title($this->postring->valid($_POST['title'], 'xss')),
				'active' => $this->postring->valid($_POST['active'], 'xss')
			);
			$query_judul = $this->podb->update('judul')
				->set($judul)
				->where('id_judul', $this->postring->valid($_POST['id'], 'sql'));
			$query_judul->execute();
			$this->poflash->success($GLOBALS['_']['banner_judul_message_2'], 'admin.php?mod=banner&act=judul');
		}
		$id = $this->postring->valid($_GET['id'], 'sql');
		$current_judul = $this->podb->from('judul')
			->where('id_judul', $id)
			->limit(1)
			->fetch();
		if (empty($current_judul)) {
			echo $this->pohtml->error();
			exit;
		}
		?>
		<div class="block-content">
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->headTitle($GLOBALS['_']['banner_judul_edit']);?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?=$this->pohtml->formStart(array('method' => 'post', 'action' => 'route.php?mod=banner&act=editjudul', 'autocomplete' => 'off'));?>
						<?=$this->pohtml->inputHidden(array('name' => 'id', 'value' => $current_judul['id_judul']));?>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->inputText(array('type' => 'text', 'label' => $GLOBALS['_']['banner_title'], 'name' => 'title', 'id' => 'title', 'value' => $current_judul['title'], 'mandatory' => true, 'options' => 'required'));?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?php
									if ($current_judul['active'] == 'N') {
										$radioitem = array(
											array('name' => 'active', 'id' => 'active', 'value' => 'Y', 'options' => '', 'title' => 'Y'),
											array('name' => 'active', 'id' => 'active', 'value' => 'N', 'options' => 'checked', 'title' => 'N')
										);
										echo $this->pohtml->inputRadio(array('label' => $GLOBALS['_']['banner_active'], 'mandatory' => true), $radioitem, $inline = true);
									} else {
										$radioitem = array(
											array('name' => 'active', 'id' => 'active', 'value' => 'Y', 'options' => 'checked', 'title' => 'Y'),
											array('name' => 'active', 'id' => 'active', 'value' => 'N', 'options' => '', 'title' => 'N')
										);
										echo $this->pohtml->inputRadio(array('label' => $GLOBALS['_']['banner_active'], 'mandatory' => true), $radioitem, $inline = true);
									}
								?>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<?=$this->pohtml->formAction();?>
							</div>
						</div>
					<?=$this->pohtml->formEnd();?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus judul.
	 *
	 * This function is used to display and process delete judul page.
	 *
	*/
	public function deletejudul()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$query = $this->podb->deleteFrom('judul')->where('id_judul', $this->postring->valid($_POST['id'], 'sql'));
			$query->execute();
			$this->poflash->success($GLOBALS['_']['banner_judul_message_3'], 'admin.php?mod=banner&act=judul');
		}
	}

	/**
	 * Fungsi ini digunakan untuk menampilkan dan memproses halaman hapus multi judul.
	 *
	 * This function is used to display and process multi delete judul page.
	 *
	*/
	public function multideletejudul()
	{
		if (!$this->auth($_SESSION['leveluser'], 'banner', 'delete')) {
			echo $this->pohtml->error();
			exit;
		}
		if (!empty($_POST)) {
			$totaldata = $this->postring->valid($_POST['totaldata'], 'xss');
			if ($totaldata != "0") {
				$items = $_POST['item'];
				foreach($items as $item){
					$query = $this->podb->deleteFrom('judul')->where('id_judul', $this->postring->valid($item['deldata'], 'sql'));
					$query->execute();
				}
				$this->poflash->success('Banner has been successfully deleted', 'admin.php?mod=banner&act=judul');
			} else {
				$this->poflash->error('Error deleted banner data', 'admin.php?mod=banner&act=judul');
			}
		}
	}

}